/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "lpc17xx.h"
#include "RIT.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include "../timer/timer.h"
#include "../button_EXINT/button.h"
#include "../game/game.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

volatile int down_0 = 0;
volatile int down_1 = 0;
volatile int down_2 = 0;

extern int gametime;
extern int **board;
char move;
int player;
//int wallScreen.x;
//int wallScreen.y;
int wallmode;
int vertical;
int wallsP1;
int wallsP2;
int headsup=0;

typedef struct{
	int x;
	int y;
}coords;
coords wallScreen;
coords wallMatrix;
extern coords player1;
extern coords player2;




void RIT_IRQHandler (void)
{					
	int success1=0;
	int success2=0;
	int i=0;
	
	char buffer[5]="";
	static int J_select=0;
	static int J_down = 0;
	static int J_left = 0;
	static int J_right = 0;
	static int J_up = 0;
		
	//JOYSTICK SELECT
	if((LPC_GPIO1->FIOPIN & (1<<25)) == 0 && mode==1){	
		/* Joytick J_Select pressed p1.25*/
		
		J_select++;
		switch(J_select){
			case 1:
				//moves player
				if (wallmode==0 && mode==1){
					int temp;
					temp=move_player(player,move);
					//checks if move was valid
					if (temp!=-1){
						if(player==0){
							//saving move
							temp=save_move(player,wallmode,1-vertical,player1.x*35/2,player1.y*35/2);
							//p1 has won
							if (player1.y==0){
								mode=2;
								disable_timer(0);
								reset_timer(0);
								LCD_Clear(White);
								GUI_Text(90,120,(uint8_t *)"P1 wins!",Black,White);
							}
						}
						else{
							temp=save_move(player,wallmode,1-vertical,player2.x*35/2,player2.y*35/2);
							//p2 has won
							if (player2.y==12){
								mode=2;
								disable_timer(0);
								reset_timer(0);
								LCD_Clear(White);
								GUI_Text(90,120,(uint8_t *)"P2 wins!",Black,White);
							}
						}
						player=1-player;
					}
					move=' ';
				}
				else if (wallmode==1 && mode==1){
					int temp=0;
					save_wall(wallMatrix.x,wallMatrix.y,vertical);
					success1= check_trap(0,wallMatrix.x,wallMatrix.y,vertical);
					success2= check_trap(1,wallMatrix.x,wallMatrix.y,vertical);
 					if (success1==1 && success2==1){
						remove_highlights();
						if (vertical==0){
							for (i=0;i<4;i++){
								LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Blue);
							}
						}
						else{
							for (i=0;i<4;i++){
								board[wallMatrix.y+i][wallMatrix.x]=2;
								LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Blue);
							}
						}
						if (player==0){
							wallsP1--;
							sprintf(buffer, "%d", wallsP1);
							GUI_Text(45, 290, (uint8_t *) buffer, Black, White);
						}
						else{
							wallsP2--;
							sprintf(buffer, "%d", wallsP2);
							GUI_Text(195, 290, (uint8_t *) buffer, Black, White);
						}
						
						temp=save_move(player,wallmode,1-vertical,wallScreen.x,wallScreen.y);
						wallScreen.x=105;
						wallScreen.y=136;
						vertical=0;		
						wallmode=0;
						player=1-player;
						start_turn(player);
					}
					else
					{
					if (vertical==0){
							for (i=0;i<4;i++){
								LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Red);
							}
							for (i=0;i<4;i++){
								LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
							}
						}
						else{
							for (i=0;i<4;i++){
								board[wallMatrix.y+i][wallMatrix.x]=2;
								LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Red);
							}
							for (i=0;i<4;i++){
								board[wallMatrix.y+i][wallMatrix.x]=2;
								LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
							}
						}
					}
				}
				
				break;
			default:
				break;
		}
	}
	else{
			J_select=0;
	}
	
	// JOYSTICK DOWN
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0 && mode==1){	
		int control=0;
		int j=0;
		J_down++;
		switch(J_down){
			case 1:
				//Saves desired move
				if(wallmode==0){
					move='d';
				}
				//Realtime checking of available spaces in the desired direction
				else if (wallmode==1 && mode==1){
					if (vertical==0){
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						}
						wallScreen.y=wallScreen.y+(35*(j/2));
						wallMatrix.y=wallMatrix.y+j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
					}
					else{
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						}
						wallScreen.y=wallScreen.y+(35*(j/2));
						wallMatrix.y=wallMatrix.y+j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
						}
					}
				}
				break;
			default:
				break;
		}
	}
	else{
			J_down=0;
	}
	
	//JOYSTICK LEFT
	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0 && mode==1){
		int control=0;
		int j;
		J_left++;
		switch(J_left){
			case 1:
				//Saves desired move
				if(wallmode==0){
					move='l';
				}
				//Realtime checking of available spaces in the desired direction
				else if (wallmode==1 && mode==1){
					if (vertical==0){
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x-j,wallMatrix.y,vertical);
						}
						wallScreen.x=wallScreen.x-(35*(j/2));
						wallMatrix.x=wallMatrix.x-j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
					}
					else{
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
						}
						
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x-j,wallMatrix.y,vertical);
						}
						wallScreen.x=wallScreen.x-(35*(j/2));
						wallMatrix.x=wallMatrix.x-j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
						}
					}
					
				}
				break;
			default:
				break;
		}
	}
	else{
			J_left=0;
	}
	
	//JOYSTICK RIGHT
	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0 && mode==1){
		int control=0;
		int j;
		J_right++;
		switch(J_right){
			case 1:
				//Saves desired move
				if(wallmode==0){
					move='r';
				}
				//Realtime checking of available spaces in the desired direction
				else if (wallmode==1 && mode==1){
					if (vertical==0){
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x+j,wallMatrix.y,vertical);
						}
						wallScreen.x=wallScreen.x+(35*(j/2));
						wallMatrix.x=wallMatrix.x+j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
					}
					else{
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x+j,wallMatrix.y,vertical);
						}
						wallScreen.x=wallScreen.x+(35*(j/2));
						wallMatrix.x=wallMatrix.x+j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
						}
					}
					
				}
				break;
			default:
				break;
		}
	}
	else{
			J_right=0;
	}
	
	//JOYSTICK UP
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0 && mode==1){
		int control=0;
		int j;
		J_up++;
		switch(J_up){
			case 1:
				//Saves desired move
				if(wallmode==0 && mode==1){
					move='u';
				}
				//Realtime checking of available spaces in the desired direction
				else if (wallmode==1 && mode==1){
					if (vertical==0){
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y-j,vertical);
						}
						wallScreen.y=wallScreen.y-(35*(j/2));
						wallMatrix.y=wallMatrix.y-j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
					}
					//Same but with a vertical wall
					else{
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
						}
						j=0;
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y-j,vertical);
						}
						wallScreen.y=wallScreen.y-(35*(j/2));
						wallMatrix.y=wallMatrix.y-j;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
						}
					}
					
				}
				
				break;
			default:
				break;
		}
	}
	else{
			J_up=0;
	}
	
	/* button management */
	
	
	//INT0
	if(down_0!=0 && mode==0){ 
		down_0++;
		
	if((LPC_GPIO2->FIOPIN & (1<<10)) == 0){
		char buffer[5] = "";
			switch(down_0){
				case 2:	
					GUI_Text(20,260,(uint8_t *)"                     ",Black,White);
				GUI_Text(20,290,(uint8_t *)"                          ",Black,White);
				draw_ui();
				GUI_Text(15, 270, (uint8_t *) "P1 Walls", Black, White);
				GUI_Text(165, 270, (uint8_t *) "P2 Walls", Black, White);
				player=0;
				init_board();
				start_turn(player);
				mode=1;
				gametime=20;
				wallsP1=8;
				wallsP2=8;
				sprintf(buffer, "%d", wallsP1);
				
				GUI_Text(45, 290, (uint8_t *) buffer, Black, White);
				GUI_Text(195, 290, (uint8_t *) buffer, Black, White);
				
				 sprintf(buffer, "%d", gametime);
				GUI_Text(95, 270,(uint8_t *) "       ", Black, White);
				GUI_Text(110, 270,(uint8_t *)buffer, Black, White);
				
				GUI_Text(130, 270,(uint8_t *)"s", Black, White);
				init_timer(0,0x17D7840);
				enable_timer(0);
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down_0=0;			
			NVIC_EnableIRQ(EINT0_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 20);     /* External interrupt 0 pin selection */
		}
	}
	
	
	//KEY 1 - Toggle wall mode
	if	(down_1!=0 && mode==1){
		down_1++;	
		if((LPC_GPIO2->FIOPIN & (1<<11)) == 0){	/* KEY1 pressed */
			int i=0;
				
			switch(down_1){
				case 2:				
				//checks if the current player has any walls left
				if ((wallsP1==0 && player==0) || (wallsP2==0 && player==1)){
					
					headsup=1;
					if(player==0){
						GUI_Text(15,270,(uint8_t *)"No walls",Black,White);
						GUI_Text(15,290,(uint8_t *)"left!",Black,White);
						GUI_Text(15,270,(uint8_t *)"No walls",Black,White);
						GUI_Text(15,290,(uint8_t *)"left!",Black,White);
						GUI_Text(15, 270, (uint8_t *) "        ", Black, White);
						GUI_Text(15, 290, (uint8_t *) "        ", Black, White);
						GUI_Text(15, 270, (uint8_t *) "P1 Walls", Black, White);
						GUI_Text(45, 290, (uint8_t *) "0", Black, White);
					}
						
					else{
						GUI_Text(165,270,(uint8_t *)"No walls",Black,White);
						GUI_Text(165,290,(uint8_t *)"left!",Black,White);
						GUI_Text(165,270,(uint8_t *)"No walls",Black,White);
						GUI_Text(165,290,(uint8_t *)"left!",Black,White);
						GUI_Text(165, 270, (uint8_t *) "        ", Black, White);
						GUI_Text(165, 290, (uint8_t *) "        ", Black, White);
						GUI_Text(165,270,(uint8_t *)"P2 Walls",Black,White);
						GUI_Text(195, 290, (uint8_t *) "0", Black, White);
					}
					wallmode=0;
				}
					
				else{
					//entering wallmode, setting up the wall
					if (wallmode==0){
						int control=0;
						int j=0;
						wallScreen.x=105;
						wallScreen.y=136;
						wallMatrix.x=6;
						wallMatrix.y=7;
						vertical=0;		
						wallmode=1;
						control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						}
						wallScreen.y=wallScreen.y+(35*(j/2));
						wallMatrix.y=wallMatrix.y+j;
						j=0;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
						
					}
					//exit wallmode, delete the movable wall
					else{
						wallmode=0;
						if (vertical==0){
							for (i=0;i<4;i++){
								LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
							}
						}
						else{
							for (i=0;i<4;i++){
								LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
							}
						}
					}
				}
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down_1=0;			
			NVIC_EnableIRQ(EINT1_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 22);     /* External interrupt 0 pin selection */
		}
	
	}
	
	
	if	(down_2!=0 && mode==1){
		down_2++;	
		if((LPC_GPIO2->FIOPIN & (1<<12)) == 0){
			int i;
			int control=0;
			int j=0;
			switch(down_2){
				case 2:		
				//if in wallmode, then the wall can be rotated
				if (wallmode==1){
					//horizontal to vertical
					if (vertical==0){
						
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,White);
						}
						vertical=1;
						wallMatrix.x--;
						wallMatrix.y++;
						wallScreen.x=wallScreen.x-4;
						wallScreen.y=wallScreen.y+4;
						control = check_wall(wallMatrix.x,wallMatrix.y,vertical);
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x-j,wallMatrix.y,vertical);
						}
						wallScreen.x=wallScreen.x-(35*(j/2));
						wallMatrix.x=wallMatrix.x-j;
						j=0;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,Cyan);
						}
					}
					//vertical to horizontal
					else{
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x+i,wallScreen.y,wallScreen.x+i,wallScreen.y+65,White);
						}
						vertical=0;
						wallMatrix.x++;
						wallMatrix.y--;
						wallScreen.x=wallScreen.x+4;
						wallScreen.y=wallScreen.y-4;
						control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						while(control==0){
							j=j+2;
							control = check_wall(wallMatrix.x,wallMatrix.y+j,vertical);
						}
						wallScreen.y=wallScreen.y+(35*(j/2));
						wallMatrix.y=wallMatrix.y+j;
						j=0;
						for (i=0;i<4;i++){
							LCD_DrawLine(wallScreen.x,wallScreen.y+i,wallScreen.x+65,wallScreen.y+i,Cyan);
						}
					}
				}
					break;
				default:
					break;
			}
		}
		else {	/* button released */
			down_2=0;			
			NVIC_EnableIRQ(EINT2_IRQn);							 /* enable Button interrupts			*/
			LPC_PINCON->PINSEL4    |= (1 << 24);     /* External interrupt 0 pin selection */
		}
	
	}
	
	reset_RIT();
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
	
  return;
}





/******************************************************************************
**                            End Of File
******************************************************************************/
