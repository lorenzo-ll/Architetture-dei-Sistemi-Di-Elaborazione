#include "../GLCD/GLCD.h" 
#include "../timer/timer.h"
#include "../RIT/RIT.h"
#include "game.h"

int i;
int j;
int jump;
extern int gametime;

//Matrix that keeps track of walls and players
int board[13][13]	= {
	{0,1,0,1,0,1,4,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,0,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,0,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,0,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,0,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,0,1,0,1,0,1,0,},
	{1,1,1,1,1,1,1,1,1,1,1,1,1,},
	{0,1,0,1,0,1,3,1,0,1,0,1,0,}
};


typedef struct{
		int x;
		int y;}coords;
	coords player1;
	coords player2;
	coords up;
	coords down;
	coords left;
	coords right;

//Draws board
void draw_board(){
	int x1=0,x2=30,y1=0,y2=30;
	for(j=0;j<7;j++){
		for(i=0;i<7;i++){
			LCD_DrawLine(x1, y1, x2, y1, Black);
			LCD_DrawLine(x2, y1, x2, y2, Black);
			LCD_DrawLine(x1, y2, x2, y2, Black);
			LCD_DrawLine(x1, y1, x1, y2, Black);
			x1=x1+35;
			x2=x2+35;
		}
		x1=0;
		x2=30;
		y1=y1+35;
		y2=y2+35;
	}
}

//Draws ui
void draw_ui(){
	int x1=10, x2=80, y1=260, y2=310;
	for(i=0;i<3;i++){
			LCD_DrawLine(x1, y1, x2, y1, Black);
			LCD_DrawLine(x2, y1, x2, y2, Black);
			LCD_DrawLine(x1, y2, x2, y2, Black);
			LCD_DrawLine(x1, y1, x1, y2, Black);
			x1=x1+75;
		x2=x2+75;
	}
}

//Draws player
void draw_player(int player, int x, int y){
	x=x+5;
	y=y+5;
	if (player==0){
		for(i=0;i<20;i++){
			LCD_DrawLine(x, y+i, x+20, y+i, Blue);
			
		}
	}
	else if (player==1){
		for(i=0;i<20;i++){
			LCD_DrawLine(x, y+i, x+20, y+i, Red);
		}
	}
	else if (player==2){
	for(i=0;i<20;i++){
			LCD_DrawLine(x, y+i, x+20, y+i, Yellow);
		}
	}
	else{
		for(i=0;i<20;i++){
			LCD_DrawLine(x, y+i, x+20, y+i, White);
		}
	}

}

//Saves initial coords of the players
void init_board(){
	
	player1.x=player2.x=6;
	player1.y=12;
	player2.y=0;
	
	board[player1.y][player1.x]=3;
	board[player2.y][player2.x]=4;
}

//Starts the turn, checks all available positions and calls the highlight function for every direction available
void start_turn(int player){
	jump=0;
	up.x=down.x=left.x=right.x=up.y=down.y=left.y=right.y=-100;
	gametime=21;
	
	if (player==0){
		//UP
		if(player1.y!=0){
		if(board[player1.y-1][player1.x]==1){
			if (board[player1.y-2][player1.x]==4 && board[player1.y-3][player1.x]==1){
				jump=2;
				highlight(player1.x,player1.y-4);
				up.x=player1.x;
				up.y=player1.y-4;
			}
			else if (board[player1.y-2][player1.x]!=4){
				highlight(player1.x,player1.y-2);
				up.x=player1.x;
				up.y=player1.y-2;
			}
		}
		}
		//DOWN
		if (player1.y!=12){
			if(board[player1.y+1][player1.x]==1 && board[player1.y+2][player1.x]!=4){
				highlight(player1.x,player1.y+2);
				down.x=player1.x;
				down.y=player1.y+2;	
			}
		}
		//LEFT
		if(player1.x!=0){
			if(board[player1.y][player1.x-1]==1 && board[player1.y][player1.x-2]!=4){
				//gestire poi giocatore
				highlight(player1.x-2,player1.y);
				left.x=player1.x-2;
				left.y=player1.y;
				}
		}
		//RIGHT
		if (player1.x!=12){
			if(board[player1.y][player1.x+1]==1 && board[player1.y][player1.x+2]!=4){
				highlight(player1.x+2,player1.y);
				right.x=player1.x+2;
				right.y=player1.y;
			}
		}
	}
	else if (player==1){
		//PLAYER2
		if(player2.y!=0){
			if(board[player2.y-1][player2.x]==1 && board[player2.y-2][player2.x]!=3){
				highlight(player2.x,player2.y-2);
				up.x=player2.x;
				up.y=player2.y-2;
			}
		}
		//DOWN
		if (player2.y!=12){
			if(board[player2.y+1][player2.x]==1){
				if (board[player2.y+2][player2.x]==3 && board[player2.y+3][player2.x]==1){
					jump=2;
					highlight(player2.x,player2.y+4);
					down.x=player2.x;
					down.y=player2.y+4;
			} 
				else if(board[player2.y+2][player2.x]!=3){
				highlight(player2.x,player2.y+2);
				down.x=player2.x;
				down.y=player2.y+2;}
			}
		}
		//LEFT
		if(player2.x!=0){
			if(board[player2.y][player2.x-1]==1 && board[player2.y][player2.x-2]!=3){
				highlight(player2.x-2,player2.y);
				left.x=player2.x-2;
				left.y=player2.y;
				}
		}
		//RIGHT
		if (player2.x!=12){
			if(board[player2.y][player2.x+1]==1 && board[player2.y][player2.x+2]!=3){
				highlight(player2.x+2,player2.y);
				right.x=player2.x+2;
				right.y=player2.y;
			}
		}
	}
}

//Converts logical coords into graphical coords and higlights the position
void highlight(int x, int y){
	y=(y*35)/2;
	x=(x*35)/2;
	draw_player(2,x,y);
}

//Removes all the highlights shown on screen using the saved coords of each position
void remove_highlights(){
	up.x=(up.x*35)/2;
	down.x=(down.x*35)/2;
	left.x=(left.x*35)/2;
	right.x=(right.x*35)/2;
	up.y=(up.y*35)/2;
	down.y=(down.y*35)/2;
	left.y=(left.y*35)/2;
	right.y=(right.y*35)/2;
	draw_player(3,up.x,up.y);
	draw_player(3,down.x,down.y);
	draw_player(3,left.x,left.y);
	draw_player(3,right.x,right.y);	
}

//Removes the old position and draws a new player in the new position
//The move only happens if the desired direction is accessible, hence the controls on the coords
int move_player(int player,char move){
	
	switch (move){
		//DOWN
		case 'd':
			if(down.x!=-100 && down.y!=-100){
				remove_highlights();
				if (player==0){
					draw_player(3,(player1.x*35)/2,(player1.y*35)/2);
					draw_player(player,down.x,down.y);
					board[player1.y][player1.x]=0;
					player1.y=player1.y+2;
					board[player1.y][player1.x]=3;
				}
				else if (player==1){
					draw_player(3,(player2.x*35)/2,(player2.y*35)/2);
					draw_player(player,down.x,down.y);
					board[player2.y][player2.x]=0;
					player2.y=player2.y+2+jump;
					jump=0;
					board[player2.y][player2.x]=4;
				}
				player=1-player;
				start_turn(player);	
			}
			break;
		//LEFT
		case 'l':
			if(left.x!=-100 && left.y!=-100){
				remove_highlights();
				if (player==0){
					draw_player(3,(player1.x*35)/2,(player1.y*35)/2);
					draw_player(player,left.x,left.y);
					board[player1.y][player1.x]=0;
					player1.x=player1.x-2;
					board[player1.y][player1.x]=3;
				}
				else if (player==1){
					draw_player(3,(player2.x*35)/2,(player2.y*35)/2);
					draw_player(player,left.x,left.y);
					board[player2.y][player2.x]=0;
					player2.x=player2.x-2;
					board[player2.y][player2.x]=4;
				}
				player=1-player;
				start_turn(player);	
			}
			break;
		//RIGHT
		case 'r':
			if(right.x!=-100 && right.y!=-100){
				remove_highlights();
				if (player==0){
					draw_player(3,(player1.x*35)/2,(player1.y*35)/2);
					draw_player(player,right.x,right.y);
					board[player1.y][player1.x]=0;
					player1.x=player1.x+2;
					board[player1.y][player1.x]=3;
				}
				else if (player==1){
					draw_player(3,(player2.x*35)/2,(player2.y*35)/2);
					draw_player(player,right.x,right.y);
					board[player2.y][player2.x]=0;
					player2.x=player2.x+2;
					board[player2.y][player2.x]=4;
				}
				player=1-player;
				start_turn(player);
			}
			break;
		//UP
		case 'u':
			if(up.x!=-100 && up.y!=-100){
				remove_highlights();
				if (player==0){
					draw_player(3,(player1.x*35)/2,(player1.y*35)/2);
					draw_player(player,up.x,up.y);
					board[player1.y][player1.x]=0;
					player1.y=player1.y-2-jump;
					jump=0;
					board[player1.y][player1.x]=3;
				}
				else if (player==1){
					draw_player(3,(player2.x*35)/2,(player2.y*35)/2);
					draw_player(player,up.x,up.y);
					board[player2.y][player2.x]=0;
					player2.y=player2.y-2;
					board[player2.y][player2.x]=4;
				}
				player=1-player;
				start_turn(player);
			}
			break;
			default:
				player=-1;
			break;
			
	}
	return player;
}

//Checks if the desired position for the wall is available and is not out of bounds
int check_wall(int x,int y,int vertical){
	int control = 1;
	int i;
	if (vertical==0 && x>=0 && y>=0){
		for (i=0;i<3;i++){
			if (board[y][x+i]==2)
				control=0;
		}
	}
	else if(vertical==1 && x>=0 && y>=0){
		for (i=0;i<3;i++){
			if (board[y+i][x]==2)
				control=0;
		}
	}
	if (x<0 != y<0){
		control=0;
	}
	return control;
}

//Saves wall in the logical matrix in the desired location
void save_wall(int x,int y,int vertical){
	int i=0;
	int y1=y;
	int x1=x;
	if (vertical==0){
		for (i=0;i<3;i++){
			board[y1][x1+i]=2;
		}
	}
	else if (vertical==1){
		for (i=0;i<3;i++){
			board[y1+i][x1]=2;
		}
	}	
}

//Removes the wall at the desired coords
void undo_wall(int x,int y,int vertical){
	int i=0;
	int y1=y;
	int x1=x;
	if (vertical==0){
		for (i=0;i<4;i++){
			board[y1][x1+i]=1;
		}
	}
	else if (vertical==1){
		for (i=0;i<4;i++){
			board[y1+i][x1]=1;
		}
	}
}

//Uses a flooding of a matrix to check if the last insertion of a wall traps a player.
//If a player is trapped, it won't be possible to place the wall.
//To check the entrapment, we temporarily save the new wall in the logical matrix.
//If a trap is detected, an undo wall function is called which removes the test wall.
int check_trap(int player,int x,int y,int vertical){
	int i;
	int j;
	int y1=y;
	int x1=x;
	int success=0;
	int tries=15;
	int checktable[7][7]={
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0},
		{0,0,0,0,0,0,0}};
	if (player==0)
		checktable[player1.y/2][player1.x/2]=1;
	else
		checktable[player2.y/2][player2.x/2]=1;
	//Flooding of the matrix to check if at least a "1" is able to reach the goal
	while(success==0 && tries!=0){
		for(i=0;i<7;i++){
			for(j=0;j<7;j++){
				if (checktable[i][j]==1){
					if(i==0 && player==0){
						if (checktable[i][j]==1 || checktable[i][j]==2){
							success=1;
						}
					}
					if(i==6 && player==1){
						if (checktable[i][j]==1 || checktable[i][j]==2){
							success=1;
						}
						
					}
						//UP
						if (i>0){
							if(board[i*2-1][j*2]!=2 && checktable[i-1][j]!=2){
							checktable[i-1][j]=1;
							}
						}
						//DOWN
						if (i<6){
							if(board[i*2+1][j*2]!=2 && checktable[i+1][j]!=2){
							checktable[i+1][j]=1;
							}
						}
						//LEFT
						if (j>0){
							if(board[i*2][j*2-1]!=2 && checktable[i][j-1]!=2){
							checktable[i][j-1]=1;
							}
						}
						//RIGHT
						if (j<6){
							if(board[i*2][j*2+1]!=2 && checktable[i][j+1]!=2){
							checktable[i][j+1]=1;
							}
						}
						checktable[i][j]=2;
				}
			}
		}
	tries--;
		}
	if (success==0)
		undo_wall(x1,y1,vertical);
	return success;
	}


