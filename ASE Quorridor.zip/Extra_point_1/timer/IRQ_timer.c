/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_timer.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    timer.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include <string.h>
#include "lpc17xx.h"
#include "timer.h"
#include "../GLCD/GLCD.h" 
#include "../TouchPanel/TouchPanel.h"
#include "../RIT/RIT.h"
#include "../game/game.h"

/******************************************************************************
** Function name:		Timer0_IRQHandler
**
** Descriptions:		Timer/Counter 0 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
extern int gametime;
extern int player;
extern int mode;
extern int headsup;
typedef struct{
	int x;
	int y;
}coords;
extern coords player1;
extern coords player2;
int temp;

void TIMER0_IRQHandler (void)
{
	char time_in_char[5] = "";
	if (mode==1){
		gametime--;
		if(gametime==9)
			GUI_Text(110, 270,(uint8_t *) "  ", Black, White);
		sprintf(time_in_char, "%d", gametime);
		GUI_Text(110, 270,(uint8_t *) time_in_char, Black, White);
		if (gametime==0){
			//Saves skipped move
			if(player==0)
				temp=save_move(player,0,1,player1.x*35/2,player1.y*35/2);
			else
				temp=save_move(player,0,1,player2.x*35/2,player2.y*35/2);
			remove_highlights();
			gametime=20;
			player=1-player;
			start_turn(player);
		}
	}
	
  LPC_TIM0->IR = 1;			/* clear interrupt flag */
  return;
}


/******************************************************************************
** Function name:		Timer1_IRQHandler
**
** Descriptions:		Timer/Counter 1 interrupt handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
void TIMER1_IRQHandler (void)
{
	if(headsup==1)
	{
		if(player==0){
			GUI_Text(15, 270, (uint8_t *) "        ", Black, White);
			GUI_Text(15, 290, (uint8_t *) "        ", Black, White);
			GUI_Text(15, 270, (uint8_t *) "P1 Walls", Black, White);
			GUI_Text(45, 290, (uint8_t *) "0", Black, White);
		}
		else{
			GUI_Text(165, 270, (uint8_t *) "        ", Black, White);
			GUI_Text(165, 290, (uint8_t *) "        ", Black, White);
			GUI_Text(165,270,(uint8_t *)"P2 Walls",Black,White);
			GUI_Text(195, 290, (uint8_t *) "0", Black, White);
		}
			
	}
	headsup=0;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
