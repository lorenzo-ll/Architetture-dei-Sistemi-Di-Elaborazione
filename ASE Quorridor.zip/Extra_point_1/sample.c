/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Paolo Bernardi
** Modified date:           03/01/2020
** Version:                 v2.0
** Descriptions:            basic program for LCD and Touch Panel teaching
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD/GLCD.h" 
#include "game/game.h"
#include "TouchPanel/TouchPanel.h"
#include "timer/timer.h"
#include "joystick/joystick.h"
#include "button_EXINT/button.h"
#include "RIT/RIT.h"

#define SIMULATOR 1

#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif
extern int mode;
extern int wallmode;
extern int save_move_asm(int player, int movetype, int vertical, int x, int y);

 int main(void)
{
	
	SystemInit();  												/* System Initialization (i.e., PLL)  */
	joystick_init();											/* Joystick Initialization            */
	BUTTON_init();
	mode=0;
  wallmode=0;
  LCD_Initialization();
	TP_Init();
	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec       	*/
	enable_RIT();	
	//Starting menu
	draw_board();
	draw_player(1,105,0);
	draw_player(0,105,210);
	GUI_Text(20,260,(uint8_t *)"Welcome to Quoridor!",Black,White);
	GUI_Text(20,290,(uint8_t *)"Press INT0 to start a game",Black,White);
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);						
	
  while (1)	
  {
		__ASM("wfi");
  }
}

//Saves desired move in the required format
int save_move(int player, int movetype, int vertical, int x, int y){
	volatile uint32_t res=0;
	res = save_move_asm(player,movetype,vertical,x,y);
	return res;  
}



/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
